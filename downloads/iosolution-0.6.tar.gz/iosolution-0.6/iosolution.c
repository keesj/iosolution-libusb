/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/* I've used parts of the linux USB drivers source-code as example */



#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/input.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb.h>
#include <linux/config.h>
#include <linux/errno.h>
#include <linux/kref.h>
#include <asm/uaccess.h>
#include <linux/device.h>

#include <linux/devfs_fs_kernel.h>


/*
 * Version Information	//kernel 2.6 versie!
 */

#define DRIVER_VERSION "v0.6"
#define DRIVER_AUTHOR "Klaas Noordstra,klaasnoordstraATzonnet.nl>"
#define DRIVER_DESC "USB I/O solution driver"

#define IO_VENDOR_ID 1952
#define IO_PRODUCT_ID 4097



/* Deze versie van de driver gebruikt de Device nummers van het USB gebeuren.
   De Major is dan 180 en de minor word variabel toegewezen
*/

// toewijzen vanaf deze waarde bepaald door de USB Core ook nog afhankelijk van Kernelopties
#define IOSOLUTION_MINOR_BASE 0		

//#define IOSOLUTION_NODENAME "/dev/iosolution%d"
#define MAX_IOSOLUTIONS	8
#define MAX_READSIZE 16



/* ioctl funkties  Let op Niet zomaar veranderen zie io-programma */
#define READDEVICE 1
#define GETWRITEDATA 2
#define READASCII 3


/*

	het volgende bedacht:
	schrijven : max 8 bytes schrijft naar report 0
	lezen: indeling gemaakt:
	16 bytes = 0 of 1 waardes P0.0 ... P1.7 (via shell scripts makkelijk te lezen)


	via ioctrl funktie:
	lezen van de laatst geschreven data. (maakt aanpassen via commandoregel programma's makkelijker)


*/



MODULE_AUTHOR( DRIVER_AUTHOR );
MODULE_DESCRIPTION( DRIVER_DESC );
MODULE_LICENSE("GPL");

struct usb_iosolution {
	char name[128];					/* naam gelezen uit device "leiderdorp instruments ...." */
	char devicename[64];				/* devicename of node in /dev directory */
	int index;					/* index IOsolution in tabel en nummer achter devicename */
	int open;
	int bEndpointAddress;
	int minor;					/* minor device number */
	
	struct usb_device * usbdev;			/* the usb device for this device */
	struct urb *read_urb;				/* the urb to recieve data */

	char write_buffer[8];				/* laatst geschreven data bewaren */
	char setup_packet[8];				/* setup packet */

	int reading;					/* gebruikt bij het lezen */
	int readpos;

	signed char *data;				/* input from device */
	dma_addr_t data_dma;

};


/* array of pointers to our devices that are currently connected */
static struct usb_iosolution	*devicetable[MAX_IOSOLUTIONS];


// de interrupt routine bij het ontvangen (van de chip):
// we slaan de ontvangen data op. evt is het mogelijk een signaal uit te zenden bij veranderen van een lijn
// bijv door io-control 

static void usb_iosolution_irq(struct urb *urb, struct pt_regs *regs)
{
	int status;
//	struct usb_iosolution *iosolution = urb->context;
//	signed char *data = iosolution->data;
//	printk("IOSOLUTION IRQ data= : %x %x %x %x %x %x %x %x\n",data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7]);

	switch (urb->status) {
		case 0:			/* success */
			break;
		case -ECONNRESET:	/* unlink */
		case -ENOENT:
		case -EPERM:
		case -ESHUTDOWN:	/* unplug */
		case -EILSEQ:		/* unplug timeout on uhci */
			return;
		case -ETIMEDOUT:	/* NAK */
			break;
		default:		/* error */
			warn("input irq status %d received", urb->status);
	}
	
	status = usb_submit_urb(urb, SLAB_ATOMIC);
	if (status)
		err("IOSOLUTION: unable to resubmit read urb");


}


// word aangeroepen na schrijven data
static void usb_iosolution_writecomplete(struct urb *urb, struct pt_regs *regs)
{
	if (urb->status) {
		printk ("Error writing to I/O solution device Error = %d", urb->status);
		return;
	}

}





static int usb_iosolution_open(struct inode *inode, struct file *file)
{
	struct usb_iosolution *iosolution = NULL;
 	
	unsigned int minor = iminor(inode);
	int i;
	
	for (i=0; i < MAX_IOSOLUTIONS; i++){
	if (devicetable[i] != NULL && devicetable[i]->minor == minor ) {
		iosolution = devicetable[i];
		break;
		}
	}
	
	if (iosolution == NULL) return -ENODEV;		/* unplugged ?? */
	
//	printk(KERN_INFO "iosolution opened :%s\n", iosolution->devicename);

	/* save our object in the file's private structure */
	file->private_data = iosolution;		/* store info for device */

	iosolution->readpos = 0;			/* bug if opening more then once */
	if (iosolution->open++)	return 0;

	if (iosolution->reading) return 0;		/* read urb submitted ? ja dan klaar  */
	
	iosolution->reading ++;				/* lezen eenmalig starten */
	if (usb_submit_urb(iosolution->read_urb, GFP_KERNEL)) {		// lezen gaat interrupt gestuurd */
		iosolution->open--;
		return -EIO;
	}
	return 0;
}



/* close the file */

static int usb_iosolution_release(struct inode *node, struct file *file)
{
	struct usb_iosolution *iosolution;
	iosolution = (struct usb_iosolution *)file->private_data;
	if (iosolution == NULL) return -ENODEV;		/* no device ?? */
	if (iosolution->open <= 0) return -ENODEV;	/* not opened ? */

	iosolution->open--;				/* decrease open count */
							/* we keep reading the device */
	iosolution->readpos = 0;
	
//	printk(KERN_INFO "iosolution gesloten\n");

	return 0;
}



// lezen uit de device we geven ascii tekens terug ivm verwerken door shell scripts
static ssize_t usb_iosolution_read (struct file *file, char *buffer, size_t count, loff_t *ppos)
{
	struct usb_iosolution *iosolution;
	int retval,len,i,j,a = 0;
	char s[MAX_READSIZE+8];

	iosolution = (struct usb_iosolution *)file->private_data;
	if (iosolution == NULL) return -ENODEV;		/* no device ?? */

	if (iosolution->open <= 0) return -ENODEV;	/* not opened ? */

	/* verify that the device wasn't unplugged */
	if (iosolution->usbdev == NULL) return -ENODEV;

	if (iosolution->readpos > MAX_READSIZE) return 0;	/* no more data */
	

	/* deliver the goods */

		j=128; a= iosolution->data[0];
  		for (i=0; i< 8; i++)
    		{   if (a & j) s[i]='1'; else s[i]='0';
            	    j >>= 1;
     		}

		j=128;a=iosolution->data[1];
  		for (i=8; i< 8+8; i++)
    		{   if (a & j) s[i]='1'; else s[i]='0';
        	    j >>= 1;
     		}

	/* we kopieren data (max 16 bytes) naar de user */

	j = MAX_READSIZE-iosolution->readpos;		/* max aantal door te geven bytes */
	if (count > j) len = j; else len = count;
	

	if (copy_to_user (buffer,&s[iosolution->readpos],len))
			retval = -EFAULT;
		else
			retval = len;

	iosolution->readpos += len;
	

	return retval;

}


/*
 setup packet info:
Offset		Field		Size		Value		Description
0		bmRequestType	1		Bit-Map		D7 Data Phase Transfer Direction
									0 = Host to Device
									1 = Device to Host
								D6..5 Type
									0 = Standard
									1 = Class
									2 = Vendor
									3 = Reserved
								D4..0 Recipient
									0 = Device
									1 = Interface
									2 = Endpoint
									3 = Other
								4..31 = Reserved

1		bRequest	1		Value		Request

2		wValue		2		Value		Value

4		wIndex		2		Index or Offset	Index

6		wLength		2		Count		Number of bytes to transfer if there is a data phase

*/


// schrijf data naar een iosolution:
ssize_t usb_iosolution_write (struct file *file, const char *buffer, size_t count, loff_t *ppos)
{
	struct usb_iosolution *iosolution;
	struct urb *urb;
	int retval = 0;
	int i,pipe;
	char *buf = NULL;
	
	iosolution = (struct usb_iosolution *)file->private_data;
	if (iosolution == NULL) return -ENODEV;		/* no device ?? */
	if (iosolution->open <= 0) return -ENODEV;	/* not opened ? */
	/* verify that the device wasn't unplugged */
	if (iosolution->usbdev == NULL) return -ENODEV;
	/* verify that we actually have some data to write */
	if (count == 0)  return 0;
	/* of niet teveel...*/
	if (count > 8) count = 8;
		
	/* create a urb, and a buffer for it, and copy the data to the urb */
	urb = usb_alloc_urb(0, GFP_KERNEL);
	if (!urb) {
		retval = -ENOMEM;
		goto error;
	}

	buf = usb_buffer_alloc(iosolution->usbdev, count, GFP_KERNEL, &urb->transfer_dma);
	if (!buf) {
		retval = -ENOMEM;
		goto error;
	}

	if (copy_from_user(buf, buffer, count)) {
		retval = -EFAULT;
		goto error;
	}

	memcpy(&iosolution->write_buffer[0],buf,count);		// bewaar laast geschreven data voor in/uitzetten 
								// enkele lijn..
	// setup packet initialiseren:
	
	for (i=0; i < 8; i++) iosolution->setup_packet[i] = 0;
	iosolution->setup_packet[0] = 0x22;
	iosolution->setup_packet[1] = 0x09;
	iosolution->setup_packet[3] = 0x00;	// was eerst 02 ??
	iosolution->setup_packet[6] = 0x08;	// update aug-2005 Lengte data dank aan Johan Swenker.

	
	pipe = usb_sndctrlpipe(iosolution->usbdev,0);
	
	usb_fill_control_urb (urb,
			iosolution->usbdev,
			pipe,
			&iosolution->setup_packet[0],
			buf,
			8,
			usb_iosolution_writecomplete,
			iosolution);
			
	/* send the data out usb port */
	retval = usb_submit_urb(urb, GFP_KERNEL);
	if (retval) {
		err("%s - failed submitting write urb, error %d", __FUNCTION__, retval);
		goto error;
	}

	/* release our reference to this urb, the USB core will eventually free it entirely */
	usb_free_urb(urb);
	return count;

error:
	usb_buffer_free(iosolution->usbdev, count, buf, urb->transfer_dma);
	usb_free_urb(urb);
	return retval;

}



static int usb_iosolution_ioctl (struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct usb_iosolution *iosolution;
	char s[32];
	int a,i,j;

	iosolution = (struct usb_iosolution *)file->private_data;
	if (iosolution == NULL) return -ENODEV;		/* no device ?? */
	if (iosolution->open <= 0) return -ENODEV;	/* not opened ? */

	/* verify that the device wasn't unplugged */
	if (iosolution->usbdev == NULL) return -ENODEV;

	switch (cmd) {

	case READDEVICE:
		{	return iosolution->data[0] + (iosolution->data[1] * 256);}

	case GETWRITEDATA:
			return copy_to_user((void *) arg, &iosolution->write_buffer[0], 8);

	case READASCII:
		j=128; a= iosolution->data[0];
  		for (i=0; i< 8; i++)
    		{   if (a & j) s[i]='1'; else s[i]='0';
            	    j >>= 1;
     		}

		j=128;a=iosolution->data[1];
  		for (i=8; i< 8+8; i++)
    		{   if (a & j) s[i]='1'; else s[i]='0';
        	    j >>= 1;
     		}
		s[i] = 0;

		return copy_to_user((void *) arg, &s[0],17);

	default:
	/* return that we did not understand this ioctl call */
	return -ENOTTY;
	}
}




static struct file_operations iosolution_fops = {
	owner:		THIS_MODULE,
	read:		usb_iosolution_read,
	write:		usb_iosolution_write,
	ioctl:		usb_iosolution_ioctl,
	open:		usb_iosolution_open,
	release:	usb_iosolution_release

};

/* 
 * usb class driver info in order to get a minor number from the usb core,
 * and to have the device registered with devfs and the driver core
 */
static struct usb_class_driver iosolution_class = {
	.name =		"iosolution000",
	.fops =		&iosolution_fops,
	.mode =		S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH,
	.minor_base =	IOSOLUTION_MINOR_BASE,
};



static int usb_iosolution_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
	struct usb_device * dev = interface_to_usbdev(intf);
	struct usb_endpoint_descriptor *endpoint;
	struct usb_iosolution *iosolution;
	struct usb_host_interface *interface;
	int pipe, maxp, i, index;
	char *buf;
	int retval = -ENOMEM;
	
//	printk(KERN_INFO "Probe begin\n");

	/* Controleer vendor en device ID */
	if ((dev->descriptor.idVendor != IO_VENDOR_ID) || (dev->descriptor.idProduct != IO_PRODUCT_ID))
	 {
	return 0;
	 }

	interface = intf->cur_altsetting;		// klakkeloos gekopieerd uit usb-muis driver
	if (interface->desc.bNumEndpoints != 1)		// allerlei controles die waarschijnlijk overbodig zijn
		return -ENODEV;				// hoeveel usb devices hebben dezefde ID's ?
	endpoint = &interface->endpoint[0].desc;
	if (!(endpoint->bEndpointAddress & 0x80))
		return -ENODEV;
	if ((endpoint->bmAttributes & 3) != 3) 
		return -ENODEV;


	/* select a "index" number */				// we maken een tabel aan voor gebruik met meer
	for (index = 0; index < MAX_IOSOLUTIONS; ++index) {	//dan 1 iosolution..
		if (devicetable[index] == NULL)
			break;
			}

	if (index >= MAX_IOSOLUTIONS) {
		printk ("Too many IOSOLUTION's connected.Can not handle this device.");
		return 0;
		}

	/* ruimte aanmaken voor de variabelen en initialiseren */
	if (!(iosolution = kmalloc(sizeof(struct usb_iosolution), GFP_KERNEL)))
		return -ENOMEM;
	memset(iosolution, 0, sizeof(struct usb_iosolution));

	iosolution->usbdev = dev;
	iosolution->bEndpointAddress= endpoint->bEndpointAddress;

	devicetable[index] = iosolution;
	iosolution->index = index;				// kan ie zichzelf terugvinden 

	usb_set_intfdata(intf, iosolution);			// verbinding usb-device <--> data
		
	/* naam samenstellen en toevoegen voor vermelding in logfiles enzo... */
	if ((buf = kmalloc(63, GFP_KERNEL))) {
	  if (dev->descriptor.iManufacturer &&
		usb_string(dev, dev->descriptor.iManufacturer, buf, 63) > 0)
			strcat(iosolution->name, buf);
	  if (dev->descriptor.iProduct &&
		usb_string(dev, dev->descriptor.iProduct, buf, 63) > 0)
			sprintf(iosolution->name, "%s %s", iosolution->name, buf);
	  kfree(buf);
	}


	iosolution->data = usb_buffer_alloc(dev, 8, SLAB_ATOMIC, &iosolution->data_dma);
	if (!iosolution->data) {
		kfree(iosolution);
		return -ENOMEM;
	}

	iosolution->read_urb = usb_alloc_urb(0, GFP_KERNEL);
	if (!iosolution->read_urb) {
		usb_buffer_free(dev, 8, iosolution->data, iosolution->data_dma);
		kfree(iosolution);
		return -ENODEV;
	}
	
	pipe = usb_rcvintpipe(dev, endpoint->bEndpointAddress);
	maxp = usb_maxpacket(dev, pipe, usb_pipeout(pipe));

	usb_fill_int_urb(iosolution->read_urb,
			 dev,
			 pipe,
			 iosolution->data,
			 (maxp > 8 ? 8 : maxp),
			 usb_iosolution_irq,
			 iosolution,
			 endpoint->bInterval);
			 
	iosolution->read_urb->transfer_dma = iosolution->data_dma;
	iosolution->read_urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
	
	/* hier word de schrijfbuffer geinitialiseerd. misschien moet dit anders afhankelijk van
	de toepassing. alles word hoog gezet en de pull up weerstanden aan 
	*/
	for (i=0; i < 8; i++) iosolution->write_buffer[i] = -1;
	iosolution->write_buffer[4] = 0;	/* initialiseren : pull up's allemaal inschakelen */
	iosolution->write_buffer[5] = 0;

	sprintf (iosolution->devicename,"iosolution%d",
			iosolution->index);// device naam instellen adhv index
		
	iosolution_class.name = &iosolution->devicename[0];
	/* De device registreren alles is startklaar */
	retval = usb_register_dev(intf, &iosolution_class);
	if (retval) {
		err("Not able to get a minor for this IOSOLUTION.\n");
		usb_set_intfdata(intf, NULL);
		goto error;
	}
	iosolution->minor = intf->minor;

	printk(KERN_INFO "%s Aangesloten op device :%s \n",
		 iosolution->name,iosolution->devicename);
error:
//	printk(KERN_INFO "Probe doorlopen en alles goed gegaan zo te zien\n");
	return 0;
}




static void usb_iosolution_disconnect(struct usb_interface *intf)
{
	int nummer;
	struct usb_iosolution *iosolution = usb_get_intfdata (intf);
	usb_set_intfdata(intf, NULL);
	if (iosolution) {
		nummer = iosolution->index;
		devicetable[nummer] = NULL;			/* remove from table */
		usb_kill_urb(iosolution->read_urb);
		usb_free_urb(iosolution->read_urb);
		usb_buffer_free(interface_to_usbdev(intf), 8, iosolution->data, iosolution->data_dma);
		/* give back our minor */
		iosolution_class.name = &iosolution->devicename[0];
		usb_deregister_dev(intf, &iosolution_class);
		kfree(iosolution);
		printk(KERN_INFO "I/O-solution #%d now disconnected\n", nummer);
	
	}
}




/* table of devices that work with this driver */
static struct usb_device_id usbio_table [] = {
	{ USB_DEVICE(IO_VENDOR_ID, IO_PRODUCT_ID) },
	{ }					/* Terminating entry */
};





MODULE_DEVICE_TABLE (usb, usbio_table);

	
static struct usb_driver usb_iosolution_driver = {
	.owner =	THIS_MODULE,
	.name =		"iosolution",
	.probe =	usb_iosolution_probe,
	.disconnect =	usb_iosolution_disconnect,
	.id_table =	usbio_table,
};

static int __init usb_iosolution_init(void)
{
	usb_register(&usb_iosolution_driver);
	info(DRIVER_VERSION ":" DRIVER_DESC " Geladen");
	return 0;
}

static void __exit usb_iosolution_exit(void)
{
	usb_deregister(&usb_iosolution_driver);
}


module_init(usb_iosolution_init);
module_exit(usb_iosolution_exit);
