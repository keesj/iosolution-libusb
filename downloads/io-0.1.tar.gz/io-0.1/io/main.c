/***************************************************************************
                          main.c  -  description
                             -------------------
    begin                : za nov 15 19:21:38 CET 2003
    copyright            : (C) 2003 by Klaas Noordstra
    email                : klaasnoordstraATzonnet.nl
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>                 
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h> 


/*

we maken een programma om de iosolution te besturen.
iosolution -px.xi0-15 R+/- h/l

-px.x  poortnummer 0.0 - 0.7 en 1.0 - 1.4
 I 0-15  stroom instelling 0.0 - 0.3 en 1.0 - 1.3
 R+/- pull up weerstanden voor alle poorten mogelijk.
 h of l poort is hoog +5v of laag 0v.

 niet genoemde opties blijven ongewijzigd dus programma lees huidige instellingen
 en voort wijzigingen door en schrijft terug.

 -di display optie : toont de waardes van de poorten (leest uit device)
 -do display geschreven info (incluis stroom en pull ups)

 -poll ??

 -d /dev/iosolution0  opgeven welk device
   
*/



/* ioctl funkties */
#define READDEVICE 1  
#define GETWRITEDATA 2
#define READASCII 3

/* poort constanten in poortnummer */
#define ALLEPOORTEN 256
#define GEENPOORT -1


char *devnaam = "/dev/iosolution0";

static unsigned char iosolution_data[8];
int file_descriptor;
int poortnummer = GEENPOORT;      /* p0.0 = 0 en p1.7 = 15 */
int optiedisplay = 0;


/* achterhalen of er een device is en waar en de data inlezen */
int init_io ()

{

      file_descriptor = open(devnaam, O_RDWR);
      if (file_descriptor < 0) { printf (" Error opening device %s  \n",devnaam);
                 exit(1);
                }       

      if  (ioctl(file_descriptor, GETWRITEDATA, (unsigned long) &iosolution_data[0]))
                  {printf ( "Error reading from device %s \n",devnaam);
                  exit (1);
                  }

      return (0);          

}  


int schrijf_data ()
{

  if ( write(file_descriptor,&iosolution_data[0],8) != 8)
        {printf ("Fout: Er is een fout ontstaan bij het schrijven naar device %s \n",devnaam);
         return (1);
        }
   else  return (0);

}



/* kijk of het poortnummer is ingevuld. */
int poortnietbekend(char optie)
{
  if (poortnummer == GEENPOORT) {
    
    printf ("Fout : %c optie niet vooraf gegaan door poort en bitnummer\n",optie );
    return (1);
    }
    else return (0);
}  




/* lees een commandoregel argument en verwerk deze in de van het device gelezen data */

int verwerk_argument(char *argument)

{
  int i,j,k,oldi,len;
  unsigned char c;
  void *ptr;
  char a;


  i = 0; oldi=i;
  len = strlen(argument);

while (i < len )
 {
  if (argument[i] == '-') i++;    /* voorbij minteken */
  a= toupper(argument[i]);
  i++;
    
  switch (a)

  {
    case '/' : return (0);      /* device naam "/dev/iosolutionxx" word elders verwerkt */

    case 'A' : /* volgende gegevens gelden voor alle poorten */

              poortnummer = ALLEPOORTEN;
              break;
    
    case 'P' :  /* nu moet volgen cijfer 0 of 1 een punt en cijfer 0-7 */
              if (argument[i+1] != '.') {
                    printf ("Fout: p moet gevolgd worden door poortnummer,punt en bitnummer\n");
                    return (1);
                    }
              if (argument[i] == '1' || argument[i] == '0' ) j = 8 * (argument[i]-'0');
                else { printf ("Fout: p moet gevolgd worden door poortnummer 0 of 1\n");
                        return (1);
                     }   
              if (argument[i+2] >= '0' && argument[i+2] <= '7')
                        j += argument[i+2]-'0';       
                 else { printf ("Fout: p moet gevolgd worden door poort,punt en bitnummer 0-7\n");
                        return(1);
                      }                                                
              poortnummer = j;
              i+=3;
              break;

    case 'I' : if (poortnietbekend('i')) return (1);
              k = 0;
              for (j=1; j<4; j++)
                {a=argument[i];
                 if ( (a >= '0') & (a <= '9')) {  k *=10;
                                                  k += (a - '0');
                                                  i++;
                                                }  
                  else j=4;
                 } 
               if (k > 15){ printf ("Fout: Stroom instelling waarde fout. waarde moet liggen tussen 0 en 15\n");
                            return (1);
                          }  
              if (poortnummer == ALLEPOORTEN)
                { j = k << 4;
                  k += j;
                 iosolution_data[0]= k;
                 iosolution_data[1]= k;
                 iosolution_data[2]= k;
                 iosolution_data[3]= k;
              } else

             {  /* stel stroom op poort x.x in */
             
              switch (poortnummer)  /* niet elk bit heeft een stroom instelling */
                {
                 case 0 : iosolution_data[1] &=0xf0;
                          iosolution_data[1] |= k;
                          break;
                 case 1 : k <<= 4;
                          iosolution_data[1] &=0x0f;
                          iosolution_data[1] |= k;
                          break;
                 case 2 : iosolution_data[0] &=0xf0;
                          iosolution_data[0] |= k;
                          break;
                 case 3 : k <<= 4;
                          iosolution_data[0] &=0x0f;
                          iosolution_data[0] |= k;
                          break;
                 case 8 : iosolution_data[3] &=0xf0;
                          iosolution_data[3] |= k;
                          break;
                 case 9 : k <<= 4;
                          iosolution_data[3] &=0x0f;
                          iosolution_data[3] |= k;
                          break;
                 case 10: iosolution_data[2] &=0xf0;
                          iosolution_data[2] |= k;
                          break;
                 case 11 : k <<= 4;
                          iosolution_data[2] &=0x0f;
                          iosolution_data[2] |= k;
                          break;
                 default: printf ("Fout: Stroominstelling kan alleen voor de laagste bits van elke poort\n");
                          return (1);
                          break;
                 } 

                            
              }  

              break;
    case 'R' :if (poortnietbekend('r')) return (1);
              if (poortnummer == ALLEPOORTEN)
                {
                switch(argument[i])
                  {
                    case '+' : iosolution_data[4] = 0; /* 0 = pull up inschakelen */
                               iosolution_data[5] = 0;
                               i++;
                               break;
                    case '-' : iosolution_data[4] = -1;
                               iosolution_data[5] = -1;
                               i++;
                               break;
                    default :  printf ("Fout: R - optie (pull up weerstanden) niet gevolgd door '+' of '-' \n");
                               return (1);
                               break;
                   }                                            
                }
              else /* poortnummer <> allepoorten */
                {      
                 switch(argument[i])
                  {
                    case '-' : if (poortnummer < 8)
                                        {c=1;
                                         c = c << poortnummer;
                                         iosolution_data[5] = iosolution_data[5] | c;
                                        }else
                                        {c=1;
                                         c <<= (poortnummer -8);
                                         iosolution_data[4] = iosolution_data[4] | c;
                                        }
                                
                                i++;
                                break;
                    case '+' : if (poortnummer < 8)
                                        {c=1;
                                         c = c << poortnummer;
                                         c = c ^ 0xff;
                                         iosolution_data[5] = iosolution_data[5] & c;
                                        }else
                                        {c=1;
                                         c <<= (poortnummer - 8);
                                         c = c ^ 0xff;
                                         iosolution_data[4] = iosolution_data[4] & c;
                                        }

                                i++;
                                break;
                    default :   printf ("Fout: R - optie (pull up weerstanden) niet gevolgd door '+' of '-' \n");
                                return (1);
                                break;
                   }
                               
                }
              break;
    case 'H' :if (poortnietbekend('h')) return (1);
              if (poortnummer == ALLEPOORTEN)
                {iosolution_data[6]= -1;
                 iosolution_data[7]=-1;
              } else
              {if (poortnummer < 8)
                {
                c=1;
                c = c << poortnummer;
                iosolution_data[7] = iosolution_data[7] | c;
                }else
                {c=1;
                c <<= (poortnummer - 8);
                iosolution_data[6] = iosolution_data[6] | c;
                }
              }
              break;
    case 'L' :if (poortnietbekend('l')) return (1);
              if (poortnummer == ALLEPOORTEN)
                {iosolution_data[6]= 0;
                 iosolution_data[7]= 0;
              } else
              {if (poortnummer < 8)
                {
                c=1;
                c = c << poortnummer;
                c = c ^ 0xff;
                iosolution_data[7] = iosolution_data[7] & c;
                }else
                {c=1;
                c <<= (poortnummer -8);
                c = c ^ 0xff;
                iosolution_data[6] = iosolution_data[6] & c;
                }  
              }
              break;
    case 'D' :a=argument[i];
              if ( (a >= '1') & (a <= '5')) {optiedisplay = a;
                                             i++;
                                            }
              else printf ("Fout : D optie (display) moet gevolgd worden door een cijfer zie help ");
              break;            

    default  :  printf (" Unknown argument. Don't know what to do with %s \n",argument);
                return (1);
              break;
                        
    }                     
                                

                                
 } /* while (i < len ) */ 
  return (0);

}  


void showstatus()

{

  switch (optiedisplay)
    {

    char buffer [32];
    int i,j;
    
    case '1' :  i= ioctl (file_descriptor,READASCII,(unsigned long) &buffer[0]);
                printf ("I/O solution read = %s \n",buffer);
                break;

    case '2' :  printf ("byte 0 :stroom P0.2 :%2d   stroom P0.3 :%2d\n",(iosolution_data[0] & 15),(iosolution_data[0] >> 4) & 15);
                printf ("byte 1 :stroom P0.0 :%2d   stroom P0.1 :%2d\n",(iosolution_data[1] & 15),(iosolution_data[1] >> 4) & 15);
                printf ("byte 2 :stroom P1.2 :%2d   stroom P1.3 :%2d\n",(iosolution_data[2] & 15),(iosolution_data[2] >> 4) & 15);
                printf ("byte 3 :stroom P1.0 :%2d   stroom P1.1 :%2d\n",(iosolution_data[3] & 15),(iosolution_data[3] >> 4) & 15);
                printf ("byte 4 :Pullup (+=aan):");
                        j=1;
                        for (i=0;i<8;i++){printf (" P1.%d:",i);
                                          if (iosolution_data[4] & j) printf ("-");   /* 0 = pull up inschakelen ??? */
                                                else printf ("+");
                                          j <<= 1;      
                                         }
                printf ("\n");
                printf ("byte 5 :Pullup (+=aan):");
                        j=1;
                        for (i=0;i<8;i++){printf (" P0.%d:",i);
                                          if (iosolution_data[5] & j) printf ("-");
                                                else printf ("+");
                                          j <<= 1;
                                         }
                printf ("\n");
                printf ("byte 6 :Data Poort 1  :");
                        j=1;
                        for (i=0;i<8;i++){printf (" P1.%d:",i);
                                          if (iosolution_data[6] & j) printf ("1");
                                                else printf ("0");
                                          j <<= 1;
                                         }
                printf ("\n");
                printf ("byte 7 :Data Poort 0  :");
                        j=1;
                        for (i=0;i<8;i++){printf (" P0.%d:",i);
                                          if (iosolution_data[7] & j) printf ("1");
                                                else printf ("0");
                                          j <<= 1;
                                         }
                printf ("\n");

                
                break;
    case '3' :  printf ("poort 1 en poort 0 LIVE data: (druk Ctrl-c om te stoppen)\n");
                i=0;
                do
                {
                i= ioctl (file_descriptor,READASCII,(unsigned long) &buffer[0]);
                printf ("poort 1 en 0 : %s \r",buffer);
                i=0;
                } while (i==0);
    
                break;
    }

}  






void displayhelp()

{
printf ("io versie 0.1  Gemaakt door Klaas Noordstra (klaasnoordstraATzonnet.nl)\n");
printf ("Besturing voor Leiderdorp Instruments I/O Solution (www.elomax.nl)\n\n");
printf ("Gebruik : <device> io -p0.0 [h/l] r[+/-] i[0..15]\n");
printf ("optioneel device is bijvoorbeeld /dev/iosolution2 standaard is /dev/iosolution0");
printf (" -px.y  x= poortnummer 0 of 1 en y = bitnummer 0..7 \n");
printf (" -a voor ALLE bits van beide poorten.\n");
printf ("Altijd als eerste optie -p of -a gebruiken!\n\n");
printf (" i[0..15] uitgangsstroom instellen. bijv i8\n");
printf (" r[+/-] Pull up weerstand inschakelen met r+ of uitschakelen r-\n");
printf (" h bit van gewenste poort op 1 \"hoog\" zetten\n");
printf (" l bit van gewenste poort op 0 \"laag\" zetten\n\n");
printf ("-d (display) toont de instellingen.\n");
printf ("   -d1 toont de huidige gelezen waarde's uit de I/O solution\n");
printf ("   -d2 toont de ingestelde waardes inclusief stroom en pullup weerstanden\n");
printf ("   -d3 toont LIVE de gelezen waardes. Als een bit hoog of laag word is dit direct te zien\n\n");
printf ("vb: io -p0.1r+i15h  Poort0.1 Pull up weerstand aktiveren, uitgangsstroom 15 en Data 1(hoog)\n");

}  




int main(int argc, char *argv[])
{
  int i;
  char *s;
  
    if (argc <= 1) 
        { displayhelp();
          return -1;
        }  


    for (i=1; i < argc; i++)            /* op zoek naar device "/dev/iosolution2" */
    { s = argv[i];
      if (s[0] == '/') {devnaam = s;
                        break;
                        }
    }
    
    if ((init_io()) ) exit (1);
 
    for (i=1; i < argc ; i++ )
    {  
    if ( verwerk_argument(argv[i])) exit (1);
    }

    
    schrijf_data();
  


    if (optiedisplay) showstatus();     /* nog laten zien hoe de zaak ervoor staat */

    close (file_descriptor);
    
  return EXIT_SUCCESS;
}
